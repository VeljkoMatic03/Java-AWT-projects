package loptica;

public class GVanOpsega extends Exception {

	public GVanOpsega() {
		super("Greska - Indeks van opsega");
	}
	
}
