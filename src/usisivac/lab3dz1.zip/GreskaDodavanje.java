package usisivac;

public class GreskaDodavanje extends Exception {
	
	public GreskaDodavanje() {
		super("Greska pri dodavanju figure u skup");
	}
	
}
