package usisivac;

public class GreskaIndeksVanOpsega extends Exception {

	public GreskaIndeksVanOpsega() {
		super("Greska - Ne postoji sledeca figura");
	}
	
}
