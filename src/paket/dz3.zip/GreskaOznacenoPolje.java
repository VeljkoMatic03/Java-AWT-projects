package paket;

public class GreskaOznacenoPolje extends Exception {
	
	public GreskaOznacenoPolje() {
		super("Greska - na polje se ne moze dodati akter!");
	}

}
